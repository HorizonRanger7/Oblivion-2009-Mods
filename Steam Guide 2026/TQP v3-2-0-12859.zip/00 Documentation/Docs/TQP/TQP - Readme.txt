----------------------------------------------------------------------
Toggleable Quantity Prompt
Version: 3.2.0
By: Waruddar & Kea
Email: warjudicator@yahoo.com
----------------------------------------------------------------------

Table of Contents
-----------------
   I. What's New?
  II. Upgrade Instructions
 III. Introduction
  IV. Installation
   V. Details
  VI. Bugs/Problems/Compatibility?
 VII. Troubleshooting
VIII. Credits
  IX. Permissions
   X. Version History

I. What's New?
--------------
v3.2.0:
  COBL support removed.
    As a result, Oblivion.esm is no longer required.
    This allows TQP to be used in Total Conversions such as Nehrim.

  OBSE v17+ now required.
    Scripts were simplified by using newer OBSE functions.

  Spell Purchases are no longer affected by the Default Action.
    They can still be auto-confirmed, you just have to hold one of the hotkeys down.

  Added support for the Quantity Prompt that appears when picking up certain items.
    It uses the same hotkeys as the Container/Barter screens.
    It is not affected by the Default Action for technical reasons.
      Either hold the hotkey down when picking the item up, or tap the hotkey when
      the prompt appears.

  Added INI support.
    It is read from when:
      1) TQP is first installed
      2) '<< Reset to Default Settings >>' is selected in the menu.
    It may be placed in one of three locations:
      1) Data\TQP.ini
      2) Data\INI\TQP.ini
      3) Data\Scripts\TQP.ini

II. Upgrade Instructions
------------------------
Just replace the old esp with the new one. It should work without doing anything 
special.

However, if you have problems:
1) Clean your save of TQP.
   a) Uninstall TQP.
   b) Load your save, and save it to a new slot.
   c) Reinstall TQP.
   d) Load your new save.
   e) You will have lost any custom hotkeys, so you'll have to set them back up.

III. Introduction
-----------------
With this mod, you can auto-confirm the quantity prompt ("How many?") and 
confirmation prompt that you get when an item or spell is transacted 
(moving/buying/selling/dropping). Items may be transacted one at a time with by 
holding down either ctrl key, or an entire stack at a time by holding down either 
shift key. These hotkeys may be customized ingame.

IV. Installation
----------------
It needs OBSE v0017 or greater to work. Get it here: http://obse.silverlock.org/

Three choices:
  1) OMOD: Load the archive in OBMM. It's in the omod-ready format.
  2) BAIN: Load the archive in Wrye Bash. It's in a BAIN-ready format.
  3) Manual: Just extract the .esp to your data directory and check it in the data 
             files.

The load order doesn't particularly matter. The only thing that might conflict is 
a game setting (iInventoryAskQuantityAt), and that is also set via script to 
ensure that it stays at the correct value (2).

V. Details
----------
When in a Container or Barter menu:
Hold either ctrl key when clicking on an item stack to auto-confirm ONE item.
Hold either shift key when clicking on an item stack to auto-confirm ALL items.

When in a Spell Purchase menu (uses the same hotkeys as the Container or Barter menu):
Hold either ctrl key when clicking on an item stack to auto-confirm ONE item.
Hold either shift key when clicking on an item stack to auto-confirm ALL items.

When in the Inventory menu (when either shift key is also pressed):
Hold either ctrl key when clicking on an item stack to auto-confirm ONE item.
Hold either alt key when clicking on an item stack to auto-confirm ALL items.

When in any of the above menus, press the left ctrl key in combination with the
  'T' key to bring up TQP's configuration menu.
The menu allows you to:
  1) Allow auto-confirmation when giving away 0 value items to a merchant.
  2) Change the Default Action to: Prompt, Single, or Stack
  3) Customize all of the keys
  4) Reset everything back to the default settings

One neat trick is to set one shift key to drop items by the stack, and leave the 
other shift key alone.

Other features:
1) Custom Default Actions:
   You may set the Default Action that occurs whenever you select an item without
   any hotkeys pressed.
   It can be set to Prompt (the normal behavior), Single, and Stack.
   For example, if you set the Default Action to Stack:
     1) Clicking without any hotkeys pressed will auto-confirm the entire stack.
     2) Clicking while holding one of the Stack hotkeys will cause the Prompts to
        appear. You may manually confirm the prompts, or press the Single or Stack
        hotkeys to auto-confirm the requisite amount.
     3) Clicking while holding one of the Single hotkeys will auto-confirm one item
        from the stack.
2) You may press the hotkeys even after the quantity/confirmation screens have
   appeared.
3) As a safety measure, auto-confirmation is disabled by default when "Giving away"
   items to a merchant. This may be enabled in the configuration menu.
4) Attempts have been made to make this work on international versions of Oblivion.
   The menu's won't be translated, but the mod 'should' work on non-English copies.
   This is completely untested, as I don't have a non-English version ;)

VI. Bugs/Problems/Compatibility?
--------------------------------
Bug #1:
   Exceedingly fast item selections with TQP enabled may cause multiple prompts
   for the same item, without it being sold/bought between each prompt.
   Currently, I have no plans to fix this issue, as it is likely
   computer/keyboard dependent (thus, no 'one size fits all' fix).
   It should occur more rarely since v3.1.0.

Compatibility #1:
  It is possible that the auto-confirm feature may conflict with mmmpld's Menu 
Escape, depending on how you have Menu Escape setup. In Menu Escape's "Auto-Do 
config." menu, make sure that "Quantity" and "Buy Confirm" are disabled.

VII. Troubleshooting
--------------------
1) Clean your save of TQP.
   a) Uninstall TQP.
   b) Load your save, and save it to a new slot.
   c) Reinstall TQP.
   d) Load your new save.
2) Ask for help in the current official thread at: 
   http://www.bethsoft.com/bgsforums/index.php?showforum=25
3) If I don't get back to you on the thread, feel free to PM me or email me. I 
typically check the board more often than I check the email listed at top.

VIII. Credits
-------------
Additional thanks to InterClaw for pointing out the bug in v3.1.0
Thanks to TheriN, who pointed out the problem with DarN's UI v1.3.2
Additional thanks to bendiwolf for testing the fix for DarN's UI v1.3.2
Thanks to haama for unwittingly pointing out a better way to detect menu's open
   in the background <_<
Thanks to InterClaw for the idea of setting Default Actions.
Thanks to Bagger for the original report about the mouse disabling bug.
Thanks to Luchaire and bendiwolf for additional reports and testing.
A huge thanks goes to zennshione for going above and beyond with helping me debug
   said bug.
Thanks to myste who made the original NO MORE "HOW MANY" PROMPTS which gave kea
   the idea for this mod.
Thanks also to Loki The Trickster God who came up with the name of this mod.
Thanks to flyfightflea for a small snippet of code that I'm no longer using ;)
Thanks to DarN for making DarN's UI compatible with TQP back when it was needed.
A big thanks to Ian and behippo and scruggs for OBSE.
And thanks to kea for giving me permission to update TQP.

IX. Permissions
---------------
I would appreciate if you contact me, but ultimately you may do whatever you want 
with this mod as long as you properly credit any and all authors.

This applies to any mod primarily authored by Waruddar.

X. Version History
------------------
  v1.1: Original Release by kea.

  v2.0: First Release by Waruddar.
        Auto-Confirm feature added.
        Shift keys allow buying/selling/moving items by the stack.
        The configuration menu access keys were changed to left ctrl key + the 'T' 
           key (for increased compatibility with other mods).

  v2.1: Ingame modifier key customization via the menu
        Code cleanup
        Fixed a bug that prevented quickly switching between modifiers
        Implemented a partial fix that helps prevent the quantity prompt from
           appearing after the confirmation screen
        Inventory modifiers added to drop items one at a time, or by the stack

  v2.2: Compatibility work: UI Changes are no longer necessary
        Code Optimization
        Menu rescripted

v2.2.1: Fixed a bug that resulted in the mouse being disabled.
        Fixed a tiny bug with resetting to defaults via the config menu.

v3.0.0: Complete rewrite to make use of OBSE v16's Menu functions.
        Removed Legacy options, including xml edits.
        Forcefully set iInventoryAskQuantityAt to 2
        Added COBL Compatibility.
        Added Default Actions.
        Added better keyboard support.
        Added versioning system to make upgrades easier.

v3.1.0: TQP has been restructured, and simplified.
        Added support for auto-confirming spell purchases.
        Added support for DarN's UI v1.3.2.
        Additional error-checking.
        Minor changes to the upgrade script.

v3.1.1: Bugfix for Default Actions.

v3.2.0: Support for Total Conversions added by removing COBL support.
        Spell purchasing is no longer affected by the Default Action.
        Scripts simplified by using newer OBSE functions: OBSE v17+ now required.
        Added support for the prompt that appears when picking up certain items.
        Added INI support.